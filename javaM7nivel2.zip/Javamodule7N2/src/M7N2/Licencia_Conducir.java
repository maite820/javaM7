package M7N2;

import java.util.*;

public class Licencia_Conducir {
	private int Id;
	private static int IdSiguiente = 1;
	private String Tipus_Licencia;
	private Date Fecha_Caducidad;
	
	public void Licencia_conducir(int cLicencia, String Tipus_Licencia, int agno, int mes, int dia) {
		this.Tipus_Licencia = Tipus_Licencia;
		GregorianCalendar calendario = new GregorianCalendar(agno, mes - 1, dia);
		Fecha_Caducidad = calendario.getTime();
		Id = IdSiguiente;
		IdSiguiente++;

	}

	public String getTipus_Licencia() {
		return Tipus_Licencia;
	}

	public Date getFecha_Caducidad() {
		return Fecha_Caducidad;
	}
	
	public int dameIdSiguiente() {
		return IdSiguiente;
	}

	public String getDatosLicencia() {
		return "el Id es :"+Id +Tipus_Licencia +Fecha_Caducidad;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("Licencia: [Tipo Licencia: ");
		sb.append(Tipus_Licencia);
		sb.append(" , fecha de caduducidad: ");
		sb.append(Fecha_Caducidad);
		sb.append("]");

		return sb.toString();
	}

	@Override
	public boolean equals(Object obj) {
		boolean b;
		if (obj == null) {
			b = false;
		} else {
			if (this == obj) {
				b = true;
			} else {
				if (obj instanceof Licencia_Conducir) {
					Licencia_Conducir other = (Licencia_Conducir) obj;
					if (this.Tipus_Licencia.equalsIgnoreCase(other.Tipus_Licencia)
							& this.Fecha_Caducidad == other.Fecha_Caducidad) {
						b = true;
					} else {
						b = false;
					}
				} else {
					b = false;
				}
			}
		}
		return b;
	}

	

	
}
