package M7N2;

import java.util.*;

public abstract class Persona {
	protected String nombre;
	protected String cognoms;
	protected Date dataNacimiento;
	protected  int cLicencia;

	public Persona(String nom, String cognoms, int agno, int mes, int dia, int cLicencia) {
		// TODO Auto-generated constructor stub
		this.nombre = nom;
		this.cognoms = cognoms;
		
		GregorianCalendar calendario = new GregorianCalendar(agno, mes - 1, dia);
		dataNacimiento = calendario.getTime();
	}

	public String getNombre() {
		return nombre;
	}

	public String getCognoms() {
		return cognoms;
	}




	public int getcLicencia() {
		return cLicencia;
	}

	

	public Date getDataNacimiento() {
		return dataNacimiento;
	
	}
	
	public  String DameDatos() {
		return "Persona [nombre=" + nombre + ", cognoms=" + cognoms + ", dataNacimiento=" + dataNacimiento
				+ ", cLicencia=" + cLicencia + "]";
	}
	

	

	static void  pedirDatosPersona() {
		
		Boolean control = true;
		
		Scanner scan = new Scanner(System.in);

		do {
			

			System.out.println("Vamos a crear un usuario nuevo, para eso necesitamos los siguientes datos: ");
			try {
				System.out.println("Introduce tu nombre: ");
				String nombre = scan.nextLine();
				if (nombre.isEmpty()) {
					throw new NullPointerException("No ha puesto nombre en el formulario");
				}
				

				System.out.println("Introduce tus apellidos: ");
				String cognoms = scan.nextLine();
				if (cognoms.isEmpty()) {
					throw new NullPointerException("No ha puesto apellido en el formulario");
				}
				

				System.out.println("Introduce tu fecha nacimiento: ");

				String dataNacimiento = scan.nextLine();
				
				if (dataNacimiento.isEmpty()) {
					throw new NullPointerException("No ha puesto la fecha de nacimiento en el formulario");
				}
				
			
				
				control = false;
				
			} catch (NullPointerException ex) {
				System.out.println("Falta alg�n dato en el formulario. Intentalo de nuevo y no te saltes nada.");
			}

		} while (control);
		
		
		
		
	}

	
				
	}
	


