package M7N2;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class UsoVehicle {

	public static void main(String[] args) {

		// MENU PARA ELEGIR CAR (COCHE) O BIKE (MOTO)
		Persona.pedirDatosPersona();
		Scanner sc = new Scanner(System.in);
		int opcion = 0;
		boolean controlType = false;

		do {
			System.out.println("Selecciona que vehiculo:");
			System.out.println("1 - Car (coche)");
			System.out.println("2 - Bike (moto)");
			System.out.println("3 - Truck (Cami�n");
			System.out.println("0 - Salir");
			try {
				opcion = sc.nextInt();
				if (opcion < 0 || opcion > 3) {
					System.out.println("Has de elegir uno de los m�meros del men�.");
					controlType = false;
				} else {
					controlType = true;
				}
			} catch (InputMismatchException e) {
				System.out.println("has de introducir un numero,gracias. ");
				sc.nextLine();
			}
		} while (!controlType);

		switch (opcion) {

		case 1:
			
			Car coche = (Car) crearVehiculo(Car.class);
			System.out.println("Hemos creado la estructura del coche.");

			
			plusDosRuedas("las ruedas traseras", coche);
			plusDosRuedas("las ruedas delanteras", coche);

			// treiem per consola perque es vegi
			mostrarConsola(coche);
			break;
		case 2:
			
			Bike bici = (Bike) crearVehiculo(Bike.class);
			System.out.println("Hemos creado la estructura de la bici.");

			
			plusUnaRueda("la rueda trasera", bici);
			plusUnaRueda("la rueda delantera", bici);

			mostrarConsola(bici);
			break;
		case 3:
			
			Truck camion = (Truck) crearVehiculo(Truck.class);
			System.out.println("Hemos creado la estructura del camion.");

			
			plusDosRuedas("las ruedas traseras", camion);
			plusDosRuedas("las ruedas delanteras", camion);

			
			mostrarConsola(camion);
			break;
			
			
			
		default:
			System.out.println("Error en lectura del men�");
			break;
		}
		sc.close();
	}

	
	public static Vehicle crearVehiculo(Class claseACrear) {
		Vehicle myVehicle;
		String plate;
		String brand;
		String color;
		Scanner sc = new Scanner(System.in);

		Boolean wrongPlate = true;
		// Seg�n lo que sea
		if (claseACrear == Car.class) {
			System.out.println("Vamos a crear un coche.");
		} else if (claseACrear == Bike.class) {
			System.out.println("Vamos a crear una bici.");
		} else if (claseACrear == Truck.class) {
			System.out.println("Vamos a crear un camion.");
		}

		do {
			System.out.println("Dime qu� matr�cula tiene:");
			plate = sc.nextLine();
			if (revisarMatricula(plate)) {
				wrongPlate = false;
			} else {
				System.out.println("La matr�cula tiene que tener 4 n�meros y de 2 a 3 letras, int�ntalo de nuevo");
			}
		} while (wrongPlate);
		System.out.println("Ahora dime de qu� marca es:");
		brand = sc.nextLine();
		System.out.println("Y por �ltimo el color que tiene:");
		color = sc.nextLine();
		
		// Seg�n lo que sea
		if (claseACrear == Car.class) {
			myVehicle = new Car(plate, brand, color);
		} else if (claseACrear == Bike.class) {
			myVehicle = new Bike(plate, brand, color);
		} else if (claseACrear == Truck.class) {
			myVehicle = new Truck (plate,brand, color);
		}
		else {
			myVehicle = null;
		}
		
		return myVehicle;
	}

	/**
	 * M�todo para a�adir 2 ruedas iguales a un objeto coche
	
	 */
	private static void plusDosRuedas(String zonaRuedas, Car myCar) {
		Wheel wheel;
		List<Wheel> pairWheels = new ArrayList<Wheel>();
		Boolean control = true;
		do {
			wheel = pedirRueda(zonaRuedas);
			pairWheels.add(wheel);
			pairWheels.add(wheel);
			try {
				myCar.addTwoWheels(pairWheels);
				control = false;
			} catch (Exception e) {
				System.out.println("Las ruedas no coinciden, prueba de nuevo. "
						+ "Las ruedas de la misma zona tienen que ser iguales para que el coche est� calibrado");
				pairWheels.clear();
			}
		} while (control);
	}

	/**
	 * M�todo para a�adir 1 ruedas a un objeto bici
	 
	 */
	private static void plusUnaRueda(String zonaRuedas, Bike myBike) {
		Wheel wheel;
		wheel = pedirRueda(zonaRuedas);
		myBike.addOneWheel(wheel);

	}
	
	private static void plusDosRuedas(String zonaRuedas, Truck myTruck) {
		Wheel wheel;
		List<Wheel> pairWheels = new ArrayList<Wheel>();
		Boolean control = true;
		do {
			wheel = pedirRueda(zonaRuedas);
			pairWheels.add(wheel);
			pairWheels.add(wheel);
			try {
				myTruck.addTwoWheels(pairWheels);
				control = false;
			} catch (Exception e) {
				System.out.println("Las ruedas no coinciden, prueba de nuevo. "
						+ "Las ruedas de la misma zona tienen que ser iguales para que el coche est� calibrado");
				pairWheels.clear();
			}
		} while (control);
	}
	/**
	 * M�tode per demanar les dades i crear una roda
	 * 
	 * @param quinaRoda missatge que indicar� quina roda ser� la que farem
	 * @return roda amb marca i diametre
	 */
	private static Wheel pedirRueda(String elegirRueda) {
		Wheel prov;
		String brand;
		Double diametre = 0.0;
		Scanner sc = new Scanner(System.in);

		System.out.print("Vamos a a�adir " + elegirRueda + ". ");
		System.out.println("Dime de qu� marca:");
		brand = sc.nextLine();
		if ("".equals(brand)) {
			System.out.println("No has introducido marca, as� que se pondr� como \"Desconocida\"");
			brand = "Desconocida";
		}

		Boolean control = true;
		do {
			System.out.println("Y dime su di�metro (en n�meros):");
			try {
				diametre = sc.nextDouble();
				if (diametre > 4 || diametre < 0.4) {
					throw new Exception("El di�metro no est� en los valores permitidos.");
				}
				control = false;
			} catch (InputMismatchException e) {
				System.out.println("Di�metro no puesto en n�meros, int�ntalo de nuevo.");
				sc.nextLine();
			} catch (Exception ex) {
				System.out.println("El valor no est� en el rango de los permitidos (de 0.4 a 4), int�ntalo de nuevo.");
				sc.nextLine();
				sc.close();
			}
		} while (control);
		prov = new Wheel(brand, diametre);
		
		return prov;
		
	}

	/**
	 * M�todo para revisar que la matr�cula est� bien formada seg�n enunciado
	 * (contenga 4 n�meros i dues o tres lletres)
	 * 
	 * @param plate Matr�cula a revisar
	 * @return true si la matr�cula es correcta false si la matr�cula es incorrecta
	 */
	private static boolean revisarMatricula(String plate) {
		char[] plateInputs = plate.toCharArray();
		boolean rightFormat = true;
		boolean otherSymbol = false;
		int numLetters = 0;
		int numDigits = 0;

		for (Character c : plateInputs) {
			if (Character.isDigit(c)) {
				numDigits++;
			} else if (Character.isLetter(c)) {
				numLetters++;
			} else {
				otherSymbol = true;
			}
		}
		// ser� incorrecta si: contiene simbolos o no contiene 4 digitos o no contiene 2
		// o 3 letras
		if (otherSymbol) {
			rightFormat = false;
		} else if (numLetters < 2 || numLetters > 3) {
			rightFormat = false;
		} else if (numDigits != 4) {
			rightFormat = false;
		}
		return rightFormat;

	}

	// M�todo para mostrar por consola los datos del veh�culo creado
	 
	private static void mostrarConsola(Vehicle vehicle) {
		// tipo de vehiculo


		System.out.print("Hemos creado el siguiente veh�culo: ");
		
		if (vehicle.getClass() == Car.class) {
			System.out.println("un coche.");
		} else if (vehicle.getClass() == Bike.class) {
			System.out.println("una bici.");
		} else if (vehicle.getClass() == Truck.class) {
			System.out.println("un cami�n.");
		}
		else {
			System.out.println("Tipo de vehiculo no informado.");
		}

		// datos b�sicos: marca, matr�cula y color
		System.out.println("Es de la marca " + vehicle.getBrand() + ", es de color " + vehicle.getColor()
				+ " y su matr�cula es \"" + vehicle.getPlate() + "\"");

		// ruedas
		
		System.out.println("Tiene " + vehicle.getWheels().size() + " ruedas. Sus detalles son:");
		if (vehicle.getClass() == Car.class) {
			System.out.println("  Las ruedas traseras son de la marca " + vehicle.getWheels().get(0).getBrand()
					+ "y de di�metro " + vehicle.getWheels().get(0).getDiameter() + ".");
			System.out.println("  Las ruedas delanteras son de la marca " + vehicle.getWheels().get(2).getBrand()
					+ "y de di�metro " + vehicle.getWheels().get(2).getDiameter() + ".");
		} else if (vehicle.getClass() == Bike.class) {
			System.out.println("  La rueda trasera es de la marca " + vehicle.getWheels().get(0).getBrand()
					+ "y de di�metro " + vehicle.getWheels().get(0).getDiameter() + ".");
			System.out.println("  La rueda trasera es de la marca " + vehicle.getWheels().get(1).getBrand()
					+ "y de di�metro " + vehicle.getWheels().get(1).getDiameter() + ".");
			
		} else {
			System.out.println("  Tipo de vehiculo no informado, ruedas no disponibles.");

		}

	}

}
