package M7N2;

public class Conductor extends Persona {

	public Conductor(String nom, String cognoms, int agno, int mes, int dia, int cLicencia) {
		super(nom, cognoms, agno, mes, dia, cLicencia);
		// TODO Auto-generated constructor stub
	}

	
}