package M7N2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Titular extends Persona {

	public Titular(String nom, String cognoms, int agno, int mes, int dia, int cLicencia) {
		super(nom, cognoms, agno, mes, dia, cLicencia);
		// TODO Auto-generated constructor stub
	}
	
		Scanner sc= new Scanner (System.in);
		
	
		public int getSeguro() {
			return Seguro;
		}
		public void setSeguro(int seguro) {
			System.out.println("Introduce numero de seguro");
			Seguro = sc.nextInt();
		}
		public String getGaraje() {
			return Garaje;
		}
		
		public void setGaraje(String garaje) {
			System.out.println("Tienes garaje propio (S/N)?");
			try {
			Garaje = sc.nextLine();
			if(Garaje.equalsIgnoreCase("S")== true) {
				System.out.println("Tienes garaje propio");
			}else {
				System.out.println("No tienes garaje propio");
			}
			}
			catch (InputMismatchException e) {
				System.out.println("has de introducir S(afirmativo) o N (Negativo),gracias. ");
				sc.nextLine();
			}
		}



@Override
		public String toString() {
			return "Titular Nombre=" +nombre+ ", Seguro=" + Seguro + ", Garaje=" + Garaje + "]";
		}



protected int Seguro;
protected String Garaje;

	}
